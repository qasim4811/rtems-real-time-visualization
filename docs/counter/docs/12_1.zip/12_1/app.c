#include <rtems.h>
#include <rtems/record.h>
#include <rtems/counter.h>
#include <stdio.h>

#define EVT_COUNT_A RTEMS_RECORD_USER(0)


rtems_id barrier_id;


void do_deterministic_work_microsecond(uint32_t microseconds) {
    uint64_t nanoseconds = (uint64_t)microseconds * 1000;
    rtems_counter_delay_nanoseconds(nanoseconds);
}

/* Task A: 100ms Period, 20ms Work */
rtems_task Task_A(rtems_task_argument arg) {
    rtems_id rm_id;
    rtems_rate_monotonic_create(rtems_build_name('R','M','A',' '), &rm_id);
    while (1) {
    rtems_counter_ticks start = rtems_counter_read();
rtems_counter_ticks end = rtems_counter_read();

rtems_counter_ticks baseline = end - start;
        rtems_rate_monotonic_period(rm_id, RTEMS_MILLISECONDS_TO_TICKS(100));
        rtems_record_produce(EVT_COUNT_A, 1); 
         start = rtems_counter_read();
        rtems_counter_delay_nanoseconds(20000*1000);
       // do_deterministic_work_microsecond(20000);
         end = rtems_counter_read();
        rtems_record_produce(EVT_COUNT_A, end - start - baseline );
       uint64_t ns = rtems_counter_ticks_to_nanoseconds(end - start - baseline);
       printf("Elapsed: %llu ns\n", ns);
       
    }
}



rtems_task Dump_Task(rtems_task_argument arg) {
    rtems_task_wake_after(RTEMS_MILLISECONDS_TO_TICKS(600));
    rtems_fatal_error_occurred(0xDEADBEEF);
}

rtems_task Init(rtems_task_argument arg) {
    printf("CPU Counter Frequency: %u Hz\n", rtems_counter_frequency());   ///1000000 Hz
    rtems_id ta, td;

  

    rtems_task_create(rtems_build_name('T','A',' ',' '), 10, 4096, RTEMS_DEFAULT_MODES, RTEMS_DEFAULT_ATTRIBUTES, &ta);
    
    rtems_task_create(rtems_build_name('D','U','M','P'), 1, 4096, RTEMS_DEFAULT_MODES, RTEMS_DEFAULT_ATTRIBUTES, &td);

    rtems_task_start(ta, Task_A, 0);
    rtems_task_start(td, Dump_Task, 0);
    rtems_task_delete(RTEMS_SELF);
}
