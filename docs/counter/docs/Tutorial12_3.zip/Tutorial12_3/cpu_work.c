#include "cpu_work.h"

#include <rtems.h>
#include <rtems/counter.h>
#include <rtems/extension.h>
#include <rtems/score/thread.h>
#include <stdbool.h>
#include <stdint.h>

#define CPU_WORK_MAX_TASKS 8


#define CPU_WORK_BARRIER() __asm__ volatile ("" ::: "memory")

typedef struct {
    rtems_id id;

    volatile rtems_counter_ticks remaining_ticks;
    volatile rtems_counter_ticks last_ticks;

    volatile bool active;
    volatile bool running;
    volatile bool finished;
} cpu_work_t;

static cpu_work_t cpu_work_table[CPU_WORK_MAX_TASKS];
static rtems_id cpu_work_extension_id;

static rtems_id cpu_work_get_thread_id(rtems_tcb *tcb)
{
    return tcb->Object.id;
}

static cpu_work_t *cpu_work_find(rtems_id id)
{
    for (int i = 0; i < CPU_WORK_MAX_TASKS; i++) {
        if (cpu_work_table[i].active && cpu_work_table[i].id == id) {
            return &cpu_work_table[i];
        }
    }

    return NULL;
}

void cpu_work_register_task(rtems_id task_id)
{
    if (cpu_work_find(task_id) != NULL) {
        return;
    }

    for (int i = 0; i < CPU_WORK_MAX_TASKS; i++) {
        if (!cpu_work_table[i].active) {
            cpu_work_table[i].id = task_id;
            cpu_work_table[i].remaining_ticks = 0;
            cpu_work_table[i].last_ticks = 0;
            cpu_work_table[i].active = true;
            cpu_work_table[i].running = false;
            cpu_work_table[i].finished = true;

            CPU_WORK_BARRIER();
            return;
        }
    }
}


static void cpu_work_account(cpu_work_t *w)
{
    rtems_counter_ticks now;
    rtems_counter_ticks used;
    rtems_counter_ticks remaining;

    if (w == NULL) {
        return;
    }

    CPU_WORK_BARRIER();

    if (!w->running || w->finished) {
        return;
    }

    now = rtems_counter_read();

    used = rtems_counter_difference(
        now,
        w->last_ticks
    );

   
    w->last_ticks = now;

    remaining = w->remaining_ticks;

    if (used >= remaining) {
        w->remaining_ticks = 0;
        w->finished = true;
        w->running = false;
    } else {
        w->remaining_ticks = remaining - used;
    }

    CPU_WORK_BARRIER();
}

static void cpu_work_switch_out(rtems_tcb *current_task)
{
    rtems_id id;
    cpu_work_t *w;

    id = cpu_work_get_thread_id(current_task);
    w = cpu_work_find(id);

    if (w == NULL) {
        return;
    }

    /*
     * Account final CPU time before task leaves the CPU.
     */
    cpu_work_account(w);

  
    w->running = false;

    CPU_WORK_BARRIER();
}

static void cpu_work_switch_in(rtems_tcb *heir_task)
{
    rtems_id id;
    cpu_work_t *w;

    id = cpu_work_get_thread_id(heir_task);
    w = cpu_work_find(id);

    if (w == NULL) {
        return;
    }

    CPU_WORK_BARRIER();

    if (w->finished) {
        return;
    }

    /*
     * Restart timestamp from resume time.
     * This prevents preempted/blocked time from being counted.
     */
    w->last_ticks = rtems_counter_read();
    w->running = true;

    CPU_WORK_BARRIER();
}

static void cpu_work_thread_switch(
    rtems_tcb *current_task,
    rtems_tcb *heir_task
)
{
    cpu_work_switch_out(current_task);
    cpu_work_switch_in(heir_task);
}

rtems_status_code cpu_work_api_init(void)
{
    rtems_extensions_table cpu_work_extensions = {
        .thread_switch = cpu_work_thread_switch
    };

    return rtems_extension_create(
        rtems_build_name('C','W','R','K'),
        &cpu_work_extensions,
        &cpu_work_extension_id
    );
}

void cpu_work_run_ms(uint32_t work_ms)
{
    rtems_id self_id;
    cpu_work_t *w;

    self_id = rtems_task_self();
    w = cpu_work_find(self_id);

   
    if (w == NULL) {
        return;
    }

    w->remaining_ticks =
        rtems_counter_nanoseconds_to_ticks(
            work_ms * 1000 * 1000
        );

    w->last_ticks = rtems_counter_read();
    w->running = true;
    w->finished = false;

    CPU_WORK_BARRIER();

    while (!w->finished) {
        CPU_WORK_BARRIER();

        if (w->running) {
            cpu_work_account(w);
        }
    }

    CPU_WORK_BARRIER();
}
