#include <rtems.h>
#include <rtems/record.h>
#include <rtems/counter.h>
#include <stdio.h>

#define EVT_COUNT_A RTEMS_RECORD_USER(0)
#define EVT_COUNT_B RTEMS_RECORD_USER(1)
#define EVT_COUNT_C RTEMS_RECORD_USER(2)

rtems_id barrier_id;
volatile int sync_taskA = 0;
volatile int sync_taskB = 0;
volatile int sync_taskC = 0;

void do_deterministic_work_millisecond(uint32_t millisecond) {
    uint64_t nanoseconds = (uint64_t)millisecond * 1000000;
    rtems_counter_delay_nanoseconds(nanoseconds);
}

/* Task A: 100ms Period, 20ms Work */
rtems_task Task_A(rtems_task_argument arg) {
    rtems_id rm_id;
    rtems_rate_monotonic_create(rtems_build_name('R','M','A',' '), &rm_id);
    while (1) {
        rtems_rate_monotonic_period(rm_id, RTEMS_MILLISECONDS_TO_TICKS(100));
        if(sync_taskA == 0) { rtems_barrier_wait(barrier_id, RTEMS_NO_TIMEOUT); sync_taskA = 1; }
        rtems_record_produce(EVT_COUNT_A, 1);

        do_deterministic_work_millisecond(20);
    }
}

/* Task B: 300ms Period, 100ms Work (Long job to be preempted) */
rtems_task Task_B(rtems_task_argument arg) {
    rtems_id rm_id;
    rtems_rate_monotonic_create(rtems_build_name('R','M','B',' '), &rm_id);
    while (1) {
        rtems_rate_monotonic_period(rm_id, RTEMS_MILLISECONDS_TO_TICKS(300));
        if(sync_taskB == 0) { rtems_barrier_wait(barrier_id, RTEMS_NO_TIMEOUT); sync_taskB = 1; }
        rtems_record_produce(EVT_COUNT_B, 1);
        
        /* This 100ms job will  be preempted by Task C */
        do_deterministic_work_millisecond(100); 
    }
}

/* Task C: 50ms Period, 10ms Work (The Preemptor) */
rtems_task Task_C(rtems_task_argument arg) {
    rtems_id rm_id;
    rtems_rate_monotonic_create(rtems_build_name('R','M','C',' '), &rm_id);
    while (1) {
        rtems_rate_monotonic_period(rm_id, RTEMS_MILLISECONDS_TO_TICKS(50));
        if(sync_taskC == 0) { rtems_barrier_wait(barrier_id, RTEMS_NO_TIMEOUT); sync_taskC = 1; }
        rtems_record_produce(EVT_COUNT_C, 1);
        do_deterministic_work_millisecond(10); 
    }
}

rtems_task Dump_Task(rtems_task_argument arg) {
    rtems_task_wake_after(RTEMS_MILLISECONDS_TO_TICKS(600));
    rtems_fatal_error_occurred(0xDEADBEEF);
}

rtems_task Init(rtems_task_argument arg) {
    printf("CPU Counter Frequency: %u Hz\n", rtems_counter_frequency());   ///1000000 Hz
    rtems_id ta, tb, tc, td;
    // Barrier for 3 tasks now
    
    rtems_barrier_create(rtems_build_name('S','Y','N','C'), RTEMS_BARRIER_AUTOMATIC_RELEASE, 3, &barrier_id);

    rtems_task_create(rtems_build_name('T','A',' ',' '), 10, 4096, RTEMS_DEFAULT_MODES, RTEMS_DEFAULT_ATTRIBUTES, &ta);
    rtems_task_create(rtems_build_name('T','B',' ',' '), 10, 4096, RTEMS_DEFAULT_MODES, RTEMS_DEFAULT_ATTRIBUTES, &tb);
    rtems_task_create(rtems_build_name('T','C',' ',' '), 10, 4096, RTEMS_DEFAULT_MODES, RTEMS_DEFAULT_ATTRIBUTES, &tc);
    rtems_task_create(rtems_build_name('D','U','M','P'), 1, 4096, RTEMS_DEFAULT_MODES, RTEMS_DEFAULT_ATTRIBUTES, &td);

    rtems_task_start(ta, Task_A, 0);
    rtems_task_start(tb, Task_B, 0);
    rtems_task_start(tc, Task_C, 0);
    rtems_task_start(td, Dump_Task, 0);
    rtems_task_delete(RTEMS_SELF);
}
