#include <rtems.h>
#include <rtems/record.h>
#include <stdio.h>
#include "cpu_work.h"

#define EVT_HIGH   RTEMS_RECORD_USER(1)
#define EVT_MED    RTEMS_RECORD_USER(2)
#define EVT_LOW    RTEMS_RECORD_USER(3)

/* Status Codes: 1=Request, 2=Obtained, 3=Released */
#define REQ     1
#define GOT     2
#define REL     3
#define woke_up 5

rtems_id sem_id;
rtems_id stop_timer_id;

void Stop_Callback(rtems_id timer, void *arg)
{
    rtems_fatal_error_occurred(0xDEADBEEF);
}

void critical_section(void)
{
    cpu_work_run_ms(10);
}

/* --- J1: TASK HIGH (Priority 10) --- */
rtems_task Task_High(rtems_task_argument arg)
{
    rtems_task_wake_after(RTEMS_MILLISECONDS_TO_TICKS(15));

    rtems_record_produce(EVT_HIGH, REQ);
    rtems_semaphore_obtain(sem_id, RTEMS_WAIT, RTEMS_NO_TIMEOUT);

    rtems_record_produce(EVT_HIGH, GOT);
    critical_section();

    rtems_semaphore_release(sem_id);
    rtems_record_produce(EVT_HIGH, REL);

    rtems_task_delete(RTEMS_SELF);
}

/* --- J2: TASK MEDIUM (Priority 20) --- */
rtems_task Task_Medium(rtems_task_argument arg)
{
    rtems_task_wake_after(RTEMS_MILLISECONDS_TO_TICKS(5));

    rtems_record_produce(EVT_MED, woke_up);
    cpu_work_run_ms(20);

    rtems_task_delete(RTEMS_SELF);
}

/* --- J3: TASK LOW (Priority 30) --- */
rtems_task Task_Low(rtems_task_argument arg)
{
    rtems_semaphore_obtain(sem_id, RTEMS_WAIT, RTEMS_NO_TIMEOUT);
    rtems_record_produce(EVT_LOW, GOT);

    critical_section();

    /* Record REL only after the actual release. */
    rtems_record_produce(EVT_LOW, REL);
    rtems_semaphore_release(sem_id);


    rtems_task_delete(RTEMS_SELF);
}

rtems_task Init(rtems_task_argument arg)
{
    rtems_id th, tm, tl;
    rtems_status_code sc;

    sc = cpu_work_api_init();
    if (sc != RTEMS_SUCCESSFUL) {
        printf("cpu_work_api_init failed: %s\n", rtems_status_text(sc));
        rtems_fatal_error_occurred(0xBAD001);
    }

    sc = rtems_timer_create(
        rtems_build_name('S','T','O','P'),
        &stop_timer_id
    );
    if (sc != RTEMS_SUCCESSFUL) {
        printf("timer create failed: %s\n", rtems_status_text(sc));
        rtems_fatal_error_occurred(0xBAD002);
    }

    sc = rtems_timer_fire_after(
        stop_timer_id,
        RTEMS_MILLISECONDS_TO_TICKS(50),
        Stop_Callback,
        NULL
    );
    if (sc != RTEMS_SUCCESSFUL) {
        printf("timer fire failed: %s\n", rtems_status_text(sc));
        rtems_fatal_error_occurred(0xBAD003);
    }

    sc = rtems_semaphore_create(
        rtems_build_name('S', 'E', 'M', '1'),
        1,
        RTEMS_BINARY_SEMAPHORE | RTEMS_PRIORITY | RTEMS_INHERIT_PRIORITY,
        0,
        &sem_id
    );
    if (sc != RTEMS_SUCCESSFUL) {
        printf("semaphore create failed: %s\n", rtems_status_text(sc));
        rtems_fatal_error_occurred(0xBAD004);
    }

    sc = rtems_task_create(
        rtems_build_name('H', 'I', 'G', 'H'),
        10,
        4096,
        RTEMS_DEFAULT_MODES,
        RTEMS_DEFAULT_ATTRIBUTES,
        &th
    );
    if (sc != RTEMS_SUCCESSFUL) {
        printf("HIGH create failed: %s\n", rtems_status_text(sc));
        rtems_fatal_error_occurred(0xBAD005);
    }

    sc = rtems_task_create(
        rtems_build_name('M', 'E', 'D', ' '),
        20,
        4096,
        RTEMS_DEFAULT_MODES,
        RTEMS_DEFAULT_ATTRIBUTES,
        &tm
    );
    if (sc != RTEMS_SUCCESSFUL) {
        printf("MED create failed: %s\n", rtems_status_text(sc));
        rtems_fatal_error_occurred(0xBAD006);
    }

    sc = rtems_task_create(
        rtems_build_name('L', 'O', 'W', ' '),
        30,
        4096,
        RTEMS_DEFAULT_MODES,
        RTEMS_DEFAULT_ATTRIBUTES,
        &tl
    );
    if (sc != RTEMS_SUCCESSFUL) {
        printf("LOW create failed: %s\n", rtems_status_text(sc));
        rtems_fatal_error_occurred(0xBAD007);
    }

    cpu_work_register_task(th);
    cpu_work_register_task(tm);
    cpu_work_register_task(tl);

    rtems_task_start(tl, Task_Low, 0);
    rtems_task_start(tm, Task_Medium, 0);
    rtems_task_start(th, Task_High, 0);

    rtems_task_delete(RTEMS_SELF);
}
