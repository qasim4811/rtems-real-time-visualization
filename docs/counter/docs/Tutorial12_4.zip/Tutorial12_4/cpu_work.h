#ifndef CPU_WORK_H
#define CPU_WORK_H

#include <rtems.h>
#include <stdint.h>

rtems_status_code cpu_work_api_init(void);
void cpu_work_register_task(rtems_id task_id);
void cpu_work_run_ms(uint32_t work_ms);

#endif
