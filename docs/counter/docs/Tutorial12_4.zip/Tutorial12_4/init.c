/*
 * RTEMS configuration
 */

#define CONFIGURE_APPLICATION_NEEDS_CLOCK_DRIVER
#define CONFIGURE_APPLICATION_NEEDS_CONSOLE_DRIVER
#define CONFIGURE_UNIFIED_WORK_AREAS
#define CONFIGURE_UNLIMITED_OBJECTS
#define CONFIGURE_MAXIMUM_TASKS 10   //you can define maximum task

#define CONFIGURE_RTEMS_INIT_TASKS_TABLE
#define CONFIGURE_INIT
#define CONFIGURE_MICROSECONDS_PER_TICK 1000  ///1ms Peroid
/*  Enable Event Recording */
#define CONFIGURE_RECORD_EXTENSIONS_ENABLED
#define CONFIGURE_RECORD_FATAL_DUMP_BASE64  //Dumps of the event records in a fatal error 
// This buffer can hold exactly 65,536 system events before it starts overwriting the oldest data.
#define CONFIGURE_RECORD_PER_PROCESSOR_ITEMS 65536 
#define CONFIGURE_MAXIMUM_USER_EXTENSIONS 1
#include <rtems/confdefs.h>
