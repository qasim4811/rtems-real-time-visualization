#include <rtems.h>
#include <rtems/record.h>
#include <stdio.h>

#define EVT_COUNT_A RTEMS_RECORD_USER(0)   /// TASK A
#define EVT_COUNT_B RTEMS_RECORD_USER(1)   /// TASK B
#define EVT_COUNT_C RTEMS_RECORD_USER(2)   /// TASK C

#define EVT_MISS_A  RTEMS_RECORD_USER(3)   /// TASK A deadline miss
#define EVT_MISS_B  RTEMS_RECORD_USER(4)   /// TASK B deadline miss
#define EVT_MISS_C  RTEMS_RECORD_USER(5)   /// TASK C deadline miss

rtems_id barrier_id;
rtems_id stop_timer_id;

volatile int sync_taskA = 0;
volatile int sync_taskB = 0;
volatile int sync_taskC = 0;


/*
 * Timer callback.
 *
 * This replaces DUMP task.
 * It does not wait for EDF scheduler to select it as a normal task.
 */
void Stop_Callback(rtems_id timer, void *arg)
{
    rtems_fatal_error_occurred(0xDEADBEEF);
}


/* Task A: 100ms Period, ~20ms Work */
rtems_task Task_A(rtems_task_argument arg)
{
    rtems_id rm_id;
    rtems_status_code sc;
    rtems_rate_monotonic_period_statistics stats;

    rtems_rate_monotonic_create(
        rtems_build_name('R','M','A',' '),
        &rm_id
    );

    while (1) {
        sc = rtems_rate_monotonic_period(
            rm_id,
            RTEMS_MILLISECONDS_TO_TICKS(100)
        );

        rtems_rate_monotonic_get_statistics(rm_id, &stats);

        if (sc == RTEMS_TIMEOUT) {
            rtems_record_produce(EVT_MISS_A, (uint32_t)stats.count);
            printf("Task A missed deadline, count=%lu\n",
                   (unsigned long)stats.count);
        }

        rtems_record_produce(EVT_COUNT_A, (uint32_t)stats.count);

        if (sync_taskA == 0) {
            rtems_barrier_wait(barrier_id, RTEMS_NO_TIMEOUT);
            sync_taskA++;
        }

        for (volatile int i = 0; i < 14000; i++);
    }
}


/* Task B: 150ms Period, 20ms work */
rtems_task Task_B(rtems_task_argument arg)
{
    rtems_id rm_id;
    rtems_status_code sc;
    rtems_rate_monotonic_period_statistics stats;

    rtems_rate_monotonic_create(
        rtems_build_name('R','M','B',' '),
        &rm_id
    );

    while (1) {
        sc = rtems_rate_monotonic_period(
            rm_id,
            RTEMS_MILLISECONDS_TO_TICKS(150)
        );

        rtems_rate_monotonic_get_statistics(rm_id, &stats);

        if (sc == RTEMS_TIMEOUT) {
            rtems_record_produce(EVT_MISS_B, (uint32_t)stats.count);
            printf("Task B missed deadline, count=%lu\n",
                   (unsigned long)stats.count);
        }

        rtems_record_produce(EVT_COUNT_B, (uint32_t)stats.count);

        if (sync_taskB == 0) {
            rtems_barrier_wait(barrier_id, RTEMS_NO_TIMEOUT);
            sync_taskB++;
        }

       
        for (volatile int i = 0; i < 14000 ; i++);
    }
}


/* Task C: 200ms Period, ~20ms Work */
rtems_task Task_C(rtems_task_argument arg)
{
    rtems_id rm_id;
    rtems_status_code sc;
    rtems_rate_monotonic_period_statistics stats;

    rtems_rate_monotonic_create(
        rtems_build_name('R','M','C',' '),
        &rm_id
    );

    while (1) {
        sc = rtems_rate_monotonic_period(
            rm_id,
            RTEMS_MILLISECONDS_TO_TICKS(200)
        );

        rtems_rate_monotonic_get_statistics(rm_id, &stats);

        if (sc == RTEMS_TIMEOUT) {
            rtems_record_produce(EVT_MISS_C, (uint32_t)stats.count);
            printf("Task C missed deadline, count=%lu\n",
                   (unsigned long)stats.count);
        }

        rtems_record_produce(EVT_COUNT_C, (uint32_t)stats.count);

        if (sync_taskC == 0) {
            rtems_barrier_wait(barrier_id, RTEMS_NO_TIMEOUT);
            sync_taskC++;
        }

        for (volatile int i = 0; i < 14000; i++);
    }
}


rtems_task Init(rtems_task_argument arg)
{
    rtems_id ta, tb, tc;

    /*
     * Create synchronization barrier for Task A, Task B, Task C.
     */
    rtems_barrier_create(
        rtems_build_name('S','Y','N','C'),
        RTEMS_BARRIER_AUTOMATIC_RELEASE,
        3,
        &barrier_id
    );

    /*
     * Create stop timer.
     * This replaces DUMP task.
     */
    rtems_timer_create(
        rtems_build_name('S','T','O','P'),
        &stop_timer_id
    );

    /*
     * Fire stop timer after 700 ms.
     * This is independent of whether EDF tasks are schedulable.
     */
    rtems_timer_fire_after(
        stop_timer_id,
        RTEMS_MILLISECONDS_TO_TICKS(700),
        Stop_Callback,
        NULL
    );

    /*
     * Same base priority.
     * Under EDF scheduler, RTEMS uses absolute deadlines for these
     * periodic tasks after rtems_rate_monotonic_period() is called.
     */
    rtems_task_create(
        rtems_build_name('T','A',' ',' '),
        10,
        4096,
        RTEMS_DEFAULT_MODES,
        RTEMS_DEFAULT_ATTRIBUTES,
        &ta
    );

    rtems_task_create(
        rtems_build_name('T','B',' ',' '),
        10,
        4096,
        RTEMS_DEFAULT_MODES,
        RTEMS_DEFAULT_ATTRIBUTES,
        &tb
    );

    rtems_task_create(
        rtems_build_name('T','C',' ',' '),
        10,
        4096,
        RTEMS_DEFAULT_MODES,
        RTEMS_DEFAULT_ATTRIBUTES,
        &tc
    );

    rtems_task_start(ta, Task_A, 0);
    rtems_task_start(tb, Task_B, 0);
    rtems_task_start(tc, Task_C, 0);

    rtems_task_delete(RTEMS_SELF);
}
