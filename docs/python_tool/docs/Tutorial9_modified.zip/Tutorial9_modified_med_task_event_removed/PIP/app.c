#include <rtems.h>
#include <rtems/record.h>

#define EVT_HIGH   RTEMS_RECORD_USER(1)
#define EVT_MED    RTEMS_RECORD_USER(2)
#define EVT_LOW    RTEMS_RECORD_USER(3)

/* Status Codes: 1=Request, 2=Obtained, 3=Released */
#define REQ 1
#define GOT 2
#define REL 3
#define woke_up 5

rtems_id sem_id;

rtems_task Dump_Task(rtems_task_argument arg) {
    /* Capture exactly 50ms of activity */
    rtems_task_wake_after(RTEMS_MILLISECONDS_TO_TICKS(50));
    rtems_fatal_error_occurred(0xDEADBEEF);
}
void critical_section(void)  //10ms approx

{
    for (volatile int i = 0; i < 7500; i++); 
}
/* --- J1: TASK HIGH (Priority 10) --- */
rtems_task Task_High(rtems_task_argument arg) {
    /* Arrives at T=15ms */
    rtems_task_wake_after(RTEMS_MILLISECONDS_TO_TICKS(15));
    
    rtems_record_produce(EVT_HIGH, REQ); 
    rtems_semaphore_obtain(sem_id, RTEMS_WAIT, RTEMS_NO_TIMEOUT);
    
    rtems_record_produce(EVT_HIGH, GOT);
  /// ~10ms Critical Section
    critical_section();
    
    rtems_semaphore_release(sem_id);
    rtems_record_produce(EVT_HIGH, REL);
    rtems_task_delete(RTEMS_SELF);
}

/* --- J2: TASK MEDIUM (Priority 20) --- */
rtems_task Task_Medium(rtems_task_argument arg) {
    /* Arrives at T=5ms, preempts Low */
    rtems_task_wake_after(RTEMS_MILLISECONDS_TO_TICKS(5));
    
    rtems_record_produce(EVT_MED, woke_up); 
    /* CPU Theft: 20ms (14000 iterations) */
    for (volatile int i = 0; i < 14000; i++); 
    
    
    rtems_task_delete(RTEMS_SELF);
}

/* --- J3: TASK LOW (Priority 30) --- */
rtems_task Task_Low(rtems_task_argument arg) {
    /* Starts at T=0, grabs SEM1 immediately */
    rtems_semaphore_obtain(sem_id, RTEMS_WAIT, RTEMS_NO_TIMEOUT);
    rtems_record_produce(EVT_LOW, GOT);

    /* Critical Section: 10ms (7,000 iterations) */
    critical_section();
    rtems_record_produce(EVT_LOW, REL);
    rtems_semaphore_release(sem_id);
    //rtems_record_produce(EVT_LOW, REL);
    rtems_task_delete(RTEMS_SELF);
}

/* --- Init remains the same, just starts tasks --- */
rtems_task Init(rtems_task_argument arg) {
    rtems_id th, tm, tl, td;


    rtems_semaphore_create(
        rtems_build_name('S', 'E', 'M', '1'),
        1,
        RTEMS_BINARY_SEMAPHORE | RTEMS_PRIORITY | RTEMS_INHERIT_PRIORITY, 
        0, 
        &sem_id
    );

    rtems_task_create(rtems_build_name('H', 'I', 'G', 'H'), 10, 4096, RTEMS_DEFAULT_MODES, RTEMS_DEFAULT_ATTRIBUTES, &th);
    rtems_task_create(rtems_build_name('M', 'E', 'D', ' '), 20, 4096, RTEMS_DEFAULT_MODES, RTEMS_DEFAULT_ATTRIBUTES, &tm);
    rtems_task_create(rtems_build_name('L', 'O', 'W', ' '), 30, 4096, RTEMS_DEFAULT_MODES, RTEMS_DEFAULT_ATTRIBUTES, &tl);
    rtems_task_create(rtems_build_name('D', 'U', 'M', 'P'), 1, 4096, RTEMS_DEFAULT_MODES, RTEMS_DEFAULT_ATTRIBUTES, &td);

    rtems_task_start(tl, Task_Low, 0);
    rtems_task_start(tm, Task_Medium, 0);
    rtems_task_start(th, Task_High, 0);
    rtems_task_start(td, Dump_Task, 0);

    rtems_task_delete(RTEMS_SELF);
}
